import os
import numpy as np


data = []
dataFile = open("rawdata.txt", "r")
for line in dataFile:
    data.append(line.strip())

combined = ""
tabletext = "\\begin{tabular}"

for k in data[0].split(","):
    if len(combined) > 0:
        combined = combined + " | c "
    else:
        combined = combined + " { | c "
tabletext = tabletext + combined + " | }\n \\hline \n"
combined = ""

for i in data:
    for k in i.split(","):
        period = k.index(".")
        if len(combined) > 0:
            combined = combined + " & " + k[0:period + 3]
        else:
            combined = combined + k[0:period + 3]
    tabletext = tabletext + combined + " \\" + "\\ \n \hline \n"
    combined = ""

tabletext = tabletext + "\\end{tabular}"

print(tabletext)
