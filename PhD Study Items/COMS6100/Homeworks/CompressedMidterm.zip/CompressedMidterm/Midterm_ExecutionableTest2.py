print("Success!")
