import os
import numpy as np

fileslist = []

for r, d, f in os.walk(os.getcwd()):
    for file in f:
        fileslist.append(os.path.join(r, file))

filesarray = np.sort(np.array(fileslist))

for item in filesarray:
    if item[-3:] == '.py' and item.split("/", -1)[-1] != "prog1.py":
        withext = item.split("/", -1)[-1]
        noext = item.split("/", -1)[-1][:-3]
        os.system(f"python {withext} > {noext}.output")
    else:
        ''
