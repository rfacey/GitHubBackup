import os
import numpy as np
from matplotlib import pyplot as plt

data = []
dataFile = open("rawdata.txt", "r")
for line in dataFile:
    data.append(line.strip())
dataFile.close()

x = []
y = []

for i in data:
    x.append(float(i.split(",")[0]))
    y.append(float(i.split(",")[1]))

x = np.array(x)

y = np.array(y)

plt.plot(x, y, 'b-', label='Result')
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.grid()
plt.title('Problem2')
plt.legend(loc='upper right')
plt.savefig('problem2.jpg')
